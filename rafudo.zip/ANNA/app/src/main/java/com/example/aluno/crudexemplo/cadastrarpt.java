package com.example.aluno.crudexemplo;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.aluno.crudexemplo.CRUD.BancoOpenHelper;
import com.example.aluno.crudexemplo.DAO.PontoDAO;

public class cadastrarpt extends AppCompatActivity {
    private SQLiteDatabase conexao;
    private PontoDAO pontoDao;
    EditText nomeP, endP, cidadeP, estadoP;
    Button btnCad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrarpt);

        nomeP = (EditText) findViewById(R.id.txtNomePonto);
        endP = (EditText) findViewById(R.id.txtEnderecoPonto);
        cidadeP = (EditText) findViewById(R.id.txtCidadePonto);
        estadoP = (EditText) findViewById(R.id.txtEstadoPonto);

        btnCad = (Button) findViewById(R.id.btnCadPonto);

        btnCad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    BancoOpenHelper databaseHelper = new BancoOpenHelper(cadastrarpt.this);
                    conexao = databaseHelper.getReadableDatabase();

                    pontoDao = new PontoDAO(conexao);

                    Ponto p = new Ponto(null,12, nomeP.getText().toString(),endP.getText().toString(),cidadeP.getText().toString(),false, estadoP.getText().toString() );
                    pontoDao.cadastrar(p);

                    Toast.makeText(cadastrarpt.this, "Cadastrado com sucesso", Toast.LENGTH_LONG).show();

                }catch (Exception e){
                    e.printStackTrace();
                }

            }
        });
    }
}
