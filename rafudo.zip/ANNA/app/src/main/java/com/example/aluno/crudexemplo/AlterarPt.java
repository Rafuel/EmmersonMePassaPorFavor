package com.example.aluno.crudexemplo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class AlterarPt extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar_pt);
    }
}
