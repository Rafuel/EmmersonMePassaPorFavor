package com.example.aluno.crudexemplo.CRUD;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.aluno.crudexemplo.Tabelas;

public class BancoOpenHelper extends SQLiteOpenHelper {

        public BancoOpenHelper(Context context) {
            super(context, "Exercicio", null, 1);
        }

        public void onCreate(SQLiteDatabase db) {

            db.execSQL(Tabelas.getCreateTableUsuario());
            db.execSQL(Tabelas.getCreateTableEvento());
            db.execSQL(Tabelas.getCreateTablePonto());


        }

        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        }



}
