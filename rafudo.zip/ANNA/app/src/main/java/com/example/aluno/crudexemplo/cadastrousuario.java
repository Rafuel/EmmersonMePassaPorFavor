package com.example.aluno.crudexemplo;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.aluno.crudexemplo.CRUD.BancoOpenHelper;
import com.example.aluno.crudexemplo.DAO.UsuarioDao;

public class cadastrousuario extends AppCompatActivity {
    private SQLiteDatabase conexao;
    private UsuarioDao usuarioDAO;
    EditText nomeCad, emailcad, senhacad;
    Button btnCad;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrarpt);

        nomeCad = (EditText) findViewById(R.id.txtNomeCad);
        emailcad = (EditText) findViewById(R.id.txtEmailCad);
        senhacad = (EditText) findViewById(R.id.txtSenhaCad);

        btnCad = (Button) findViewById(R.id.btnCadastro);

        btnCad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    BancoOpenHelper databaseHelper = new BancoOpenHelper(cadastrousuario.this);
                    conexao = databaseHelper.getReadableDatabase();

                    usuarioDAO = new UsuarioDao(conexao);

                    Usuario u = new Usuario( nomeCad.getText().toString(),emailcad.getText().toString(),senhacad.getText().toString());
                    usuarioDAO.cadastrar(u);

                    Toast.makeText(cadastrousuario.this, "Cadastrado com sucesso", Toast.LENGTH_LONG).show();

                }catch (Exception e){
                    e.printStackTrace();
                }

            }
        });
    }
}
