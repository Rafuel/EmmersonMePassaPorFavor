package com.example.aluno.crudexemplo;

public class Tabelas {
    public static String getCreateTableUsuario(){

        String sql ="CREATE TABLE IF NOT EXISTS  usuario (\n" +
                "  `email` VARCHAR(50) NOT NULL,\n" +
                "  `senha` VARCHAR(20) NOT NULL,\n" +
                "  `codigo` VARCHAR(10) NOT NULL AUTO_INCREMENT,\n" +
                "  `Nome` VARCHAR(50) NOT NULL,\n" +
                "  PRIMARY KEY (`email`))";

        return sql;
    }



    public static String getCreateTableEvento(){

        String sql = "CREATE TABLE IF NOT EXISTS evento (\n" +
                "  `cod_usuario` INT NOT NULL,\n" +
                "  `codigo` INT NOT NULL AUTO_INCREMENT,\n" +
                "  `status` VARCHAR (1) NOT NULL,\n" +
                "  `nome` VARCHAR (50) NOT NULL, \n " +
                "  `data` VARCHAR (10) NOT NULL,\n" +
                "  `hora` VARCHAR (5) NOT NULL , \n" +
                "  `endereco` VARCHAR (50) NOT NULL,\n" +
                "    PRIMARY KEY (`codigo`),\n" +
                "    FOREIGN KEY (`cod_usuario`))\n" +
                "    REFERENCES usuario (`codigo`)\n";

        return sql;

    }

    public static String getCreateTablePonto(){

        String sql = "CREATE TABLE IF NOT EXISTS ponto (\n" +
                "  `cod_usuario` INT NOT NULL,\n" +
                "  `codigo` INT NOT NULL AUTO_INCREMENT,\n" +
                "  `nome` VARCHAR (50) NOT NULL,\n" +
                "  `cidade` VARCHAR (50) NOT NULL,\n" +
                "  `status` VARCHAR (1) NOT NULL,\n" +
                "  `estado` VARCHAR(50) NOT NULL,\n" +
                "  PRIMARY KEY (`codigo`),\n" +
                "    FOREIGN KEY (`cod_usuario`)\n" +
                "    REFERENCES usuario (`codigo`)\n";

        return sql;

    }

}
