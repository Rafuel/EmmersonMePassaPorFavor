package com.example.aluno.crudexemplo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.example.aluno.crudexemplo.DAO.EventoDAO;

public class CadastroEvento extends AppCompatActivity {
    EditText nomeE, dataE, horaE, enderecoE;
    Button btnCad, btnCanc;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastroevento);

        nomeE = (EditText) findViewById(R.id.textNomeE);
        dataE = (EditText) findViewById(R.id.txtDataE);
        horaE = (EditText) findViewById(R.id.txtHoraE);
        enderecoE = (EditText) findViewById(R.id.txtEnderE);
        btnCad = (Button) findViewById(R.id.btnCadastroE);
        btnCanc= (Button) findViewById(R.id.btnCancelE);

        btnCad.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EventoDAO evDao = new EventoDAO();

            }
        });

    }
}
