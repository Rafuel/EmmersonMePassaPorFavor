package com.example.aluno.crudexemplo.DAO;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.aluno.crudexemplo.Ponto;

import java.util.ArrayList;


public class PontoDAO {


    public PontoDAO(SQLiteDatabase conexao) {
    }


        private SQLiteDatabase conexao;
        private SQLiteDatabase getReadableDatabase;

    public void cadastrar(Ponto p) {
        ContentValues contentValues = new ContentValues();
        contentValues.put("nome", p.getNome());
        contentValues.put("endereco", p.getEndereco());
        contentValues.put("codigo", p.getCodigo());
        contentValues.put("cidade", p.getCidade());
        contentValues.put("status", p.isStatus());
        contentValues.put("estado", p.getEstado());
        conexao.insertOrThrow("ponto", null, contentValues);
    }



        public void alterar(Ponto pt) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("codigo", pt.getCodigo());
            String[] alt = new String[5];
            alt[0] = pt.getNome();
            alt[1] = pt.getEndereco();
            alt[2] = pt.getCidade();
            alt[3] = String.valueOf(pt.isStatus());
            alt[4] = pt.getEstado();
            conexao.update("ponto", contentValues, "codigo = ?, nome = ?, endereco = ?,  cidade = ?, status = 1, cidade = ? ", alt);
        }

        public void excluir(Ponto pt) {
            String[] del = new String[1];
            del[0] = String.valueOf(pt.getCodigo());
            conexao.delete("ponto", "codigo = ?", del);
        }

        public ArrayList<Ponto> listar() {
            SQLiteDatabase db =  this.getReadableDatabase;
            Cursor cs = db.query("evento", new String[]{"cod_usuario", "nome", "endereco", "codigo", "cidade", "status", "estado"},null,null,null,null,null);
            ArrayList<Ponto> pt =  new ArrayList<>();
            return pt;
        }


}