package com.example.aluno.crudexemplo.DAO;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.example.aluno.crudexemplo.Evento;

import java.util.ArrayList;


public class EventoDAO {
    public class EventoDao {
        private SQLiteDatabase conexao;
        private SQLiteDatabase getReadableDatabase;

        public EventoDao(SQLiteDatabase conexao) {
            this.conexao = conexao;
        }

        public void cadastrar(Evento evr) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("codigo", evr.getCodigo());
            contentValues.put("status", evr.isStatus());
            contentValues.put("nome", evr.getNome());
            contentValues.put("data", evr.getData());
            contentValues.put("hora", evr.getHora());
            contentValues.put("endereco", evr.getEndereco());
            conexao.insertOrThrow("evento", null, contentValues);
        }

        public void alterar(Evento evr) {
            ContentValues contentValues = new ContentValues();
            contentValues.put("codigo", evr.getCodigo());
            String[] alt = new String[5];
            alt[0] = String.valueOf(evr.isStatus());
            alt[1] = evr.getNome();
            alt[2] = evr.getData();
            alt[3] = evr.getHora();
            alt[4] = evr.getEndereco();
            conexao.update("evento", contentValues, "codigo = ?, status = 1, nome = ?, data = ?, hora = ?, endereco = ? ", alt);
        }

        public void excluir(Evento evr) {
            String[] del = new String[1];
            del[0] = String.valueOf(evr.getCodigo());
            conexao.delete("evento", "codigo = ?", del);
        }

        public ArrayList<Evento> listar() {
            SQLiteDatabase db =  this.getReadableDatabase;
            Cursor cs = db.query("evento", new String[]{"cod_usuario", "codigo", "status", "nome", "data", "hora", "endereco"},null,null,null,null,null);
            ArrayList<Evento> evr =  new ArrayList<>();
            return evr;
        }
    }
}
