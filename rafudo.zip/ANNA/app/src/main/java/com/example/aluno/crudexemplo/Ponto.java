package com.example.aluno.crudexemplo;

public class Ponto {
        private int codigo;
        private String nome;
        private String endereco;
        private Usuario usuario;
        private boolean status;
        private String cidade;
        private String estado;




        public Ponto(Usuario usuario, int codigo, String nome, String endereco, String cidade, boolean status, String estado) {
            this.usuario = usuario;
            this.codigo = codigo;
            this.nome = nome;
            this.endereco = endereco;
            this.cidade = cidade;
            this.status = status;
            this.estado = estado;
        }



        public boolean isStatus() {
            return status;
        }

        public void setStatus(boolean status) {
            this.status = status;
        }

        public int getCodigo() {
            return codigo;
        }

        public void setCodigo(int codigo) {
            this.codigo = codigo;
        }

        public String getNome() {
            return nome;
        }

        public void setNome(String nome) {
            this.nome = nome;
        }

        public String getEndereco() {
            return endereco;
        }

        public void setEndereco(String endereco) {
            this.endereco = endereco;
        }

        public Usuario getUsuario() {
            return usuario;
        }

        public void setUsuario(Usuario usuario) {
            this.usuario = usuario;
        }
    public String getCidade() {
        return cidade;
    }

    public void setCidade(String cidade) {
        this.cidade = cidade;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }


}
