package com.example.aluno.crudexemplo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Button;

public class TelaInicial extends AppCompatActivity {

    Button btnEvento, btnPonto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);

        btnEvento = (Button)findViewById(R.id.btnEvento);
        btnPonto = (Button)findViewById(R.id.btnPonto);
    }
}