package com.example.aluno.crudexemplo;

public class Evento {
    private boolean status;
    private int codigo;
    private String nome;
    private String data;
    private String hora;
    private String endereco;
    private Usuario usuario;
    private Ponto pontoTuristico;

    public Evento(boolean status, int codigo, String nome, String data, String hora, String endereco) {
        this.status = status;
        this.codigo = codigo;
        this.nome = nome;
        this.data = data;
        this.hora = hora;
        this.endereco = endereco;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getData() {
        return data;
    }

    public void setData(String data) {
        this.data = data;
    }

    public String getHora() {
        return hora;
    }

    public void setHora(String hora) {
        this.hora = hora;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public Ponto getPontoTuristico() {
        return pontoTuristico;
    }

    public void setPontoTuristico(Ponto pontoTuristico) {
        this.pontoTuristico = pontoTuristico;
    }

}