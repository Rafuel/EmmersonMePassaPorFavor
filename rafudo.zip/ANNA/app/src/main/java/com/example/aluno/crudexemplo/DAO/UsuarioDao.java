package com.example.aluno.crudexemplo.DAO;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import com.example.aluno.crudexemplo.Usuario;


public class UsuarioDao {
    private SQLiteDatabase conexao;
    private SQLiteDatabase getReadableDatabase;

    public UsuarioDao (SQLiteDatabase conexao){
        this.conexao =  conexao;
    }
    public void cadastrar (Usuario user){
        ContentValues contentValues =  new ContentValues();
        contentValues.put("nome", user.getNome());
        contentValues.put("email", user.getEmail());
        contentValues.put("senha", user.getSenha());
        conexao.insertOrThrow("usuario", null, contentValues);
    }
    public void alterar (Usuario user){
        ContentValues contentValues = new ContentValues();
        contentValues.put("email", user.getEmail());
         String [] alt = new String[3];
         alt [0] = user.getSenha();
         alt [2]= user.getNome();
         conexao.update("usuario", contentValues , " nome = ?,email = ?, senha = ?, codigo = ? ", alt);
    }
    public void excluir (Usuario user){
        String [] del = new String[1];
        del[0]  = user.getEmail();
        conexao.delete("usuario", "email = ?", del);
    }

}
